## 1.3.1

- Update flutter_lints to 2.0.1
- Update dev dependencies
- Resolve analyzer issues

## 1.3.0

- Bump nm plugin to 0.5.0

## 1.2.0

- Add bluetooth as connectivity result

## 1.1.1

- Dependencies update

## 1.1.0

- Add ethernet as connectivity result

## 1.0.3

- Update D-Bus package dependency

## 1.0.2

- Update connectivity plus

## 1.0.1

- Improve documentation

## 1.0.0

- Migrated to null safety
- Fixed a case with an unhandled exception

## 0.3.1

- Address pub score

## 0.3.0

- Removed members that were moved to network_info_plus

## 0.2.0

- Upgrade to latest platform interface

## 0.1.0

- Initial release for Linux.
