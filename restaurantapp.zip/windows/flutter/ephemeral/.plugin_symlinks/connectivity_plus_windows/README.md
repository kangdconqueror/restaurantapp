# Connectivity Plus Windows

[![Flutter Community: connectivity_plus_windows](https://fluttercommunity.dev/_github/header/connectivity_plus_windows)](https://github.com/fluttercommunity/community)

[![pub package](https://img.shields.io/pub/v/connectivity_plus_windows.svg)](https://pub.dev/packages/connectivity_plus_windows)

The Windows implementation of [`connectivity_plus`](https://pub.dev/packages/connectivity_plus).

## Usage

This package is already included as part of the `connectivity_plus` package dependency, and will
be included when using `connectivity_plus` as normal.
