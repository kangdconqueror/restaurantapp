package com.example.restaurantapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
